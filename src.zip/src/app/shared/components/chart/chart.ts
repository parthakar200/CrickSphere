import {
  AfterViewInit,
  Component,
  ElementRef,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  ViewChild,
  input,
} from '@angular/core';
import { Chart, ChartConfiguration, ChartType, registerables } from 'chart.js';

Chart.register(...registerables);

/**
 * Thin Angular wrapper around Chart.js. Re-creates the chart whenever
 * `data`/`type`/`options` change (simplest correct approach for a dashboard
 * where chart inputs change infrequently — a full update-in-place diff isn't
 * worth the complexity here).
 */
@Component({
  selector: 'app-chart',
  imports: [],
  template: `<div class="chart-wrap" [style.height.px]="height()">
    <canvas #canvas></canvas>
  </div>`,
  styles: [
    `
      .chart-wrap {
        position: relative;
        width: 100%;
      }
      canvas {
        max-width: 100%;
      }
    `,
  ],
})
export class AppChart implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  type = input.required<ChartType>();
  data = input.required<ChartConfiguration['data']>();
  options = input<ChartConfiguration['options']>();
  height = input<number>(280);

  private chart: Chart | null = null;

  ngAfterViewInit(): void {
    this.renderChart();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ((changes['data'] || changes['type'] || changes['options']) && this.canvasRef) {
      this.renderChart();
    }
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private renderChart(): void {
    this.chart?.destroy();

    const styles = getComputedStyle(document.documentElement);
    const textSecondary = styles.getPropertyValue('--color-text-secondary').trim();
    const border = styles.getPropertyValue('--color-border').trim();

    this.chart = new Chart(this.canvasRef.nativeElement, {
      type: this.type(),
      data: this.data(),
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: textSecondary, font: { family: 'Inter' } },
          },
        },
        scales: this.type() === 'doughnut' || this.type() === 'pie'
          ? undefined
          : {
              x: {
                ticks: { color: textSecondary },
                grid: { color: border },
              },
              y: {
                ticks: { color: textSecondary },
                grid: { color: border },
              },
            },
        ...this.options(),
      },
    });
  }
}
