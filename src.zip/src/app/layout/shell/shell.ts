import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { toSignal } from '@angular/core/rxjs-interop';
import { Sidebar } from '../sidebar/sidebar';
import { Topbar } from '../topbar/topbar';
import { ToastContainer } from '../../shared/components/toast-container/toast-container';
import { uiFeature } from '../../state/ui/ui.state';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, Sidebar, Topbar, ToastContainer],
  templateUrl: './shell.html',
  styleUrl: './shell.scss',
})
export class Shell {
  private store = inject(Store);
  private auth = inject(AuthService);

  sidebarCollapsed = toSignal(this.store.select(uiFeature.selectSidebarCollapsed), { initialValue: false });
  isAdmin = this.auth.isAdmin;
}
